<?php
session_start();
header('Content_type:text/html;charset=utf-8');
if (isset($_SESSION['userUId'])) {
	include_once 'inc/config.inc.php';
	include_once 'inc/mysqli.inc.php';
	$conn = connect();
	echo "hello {$_SESSION['userUId']}, please add your sensor!&nbsp;&nbsp;&nbsp;";
	echo "<a href='inc/logout.inc.php'>sign out</a>&nbsp;&nbsp;&nbsp;";
}else {
	echo "Illegal access <a href = 'login.php'>please login</a>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Add Sens'it</title>
</head>

<body background="images/bg5.jpg" style=" background-repeat:no-repeat ; background-size:100% 100%; background-attachment: fixed;">
<br><br><br>
<center>
<form method="post" action="inc/sensor.inc.php">
    Add Sens'it:<br><br>
    Sens'it ID: <input type="text" name="sensor_id" id="sensor" />  
    Function: 
    <select class="form-control" name="sensor_func">
    	<option>Temp and Hum</option>
        <option>Door</option>
        <option>Light</option>
        <option>Magnet</option>
        <option>Vibration</option>
    </select>  
    Remarks: <input type="text" name="remarks" id="tel" /><br><br>
    <?php 
    if (isset($_GET['error'])) {
    	if ($_GET['error'] == "emptyfields") {
	    	echo "<p style='color:red;font-size:22px'><strong>Fill in Sensor ID fields!</strong></p>";
		}
		if ($_GET['error'] == "usertaken") {
			echo "<p style='color:red;font-size:22px'><strong>This sensor has been registered!</strong></p>";
		}
    }
    if (isset($_GET['sucess'])){
	if ($_GET['success'] == "success") {
	    echo "<p style='color:red;font-size:22px'><strong>Add successfully!</strong></p>";
	}
    }
    ?>
    <button type="submit" id="addUser" name="addSensor-submit">Add</button>
    <br><br>
    <hr>
    <br><br>
    <table id="usertable" border="1" cellpadding="5" cellspacing=0>
        <tbody>
        <tr>
            <th>Sens'it ID</th>
            <th>Function</th>
            <th>Remarks</th>
            <th>Operate</th>
        </tr>
        <tr>
        
<!-- <!--         <script language="JavaScript"> --> 
<!-- //         function del(){ -->
<!-- //         	comfire=window.confirm("Do you confirm deletion?"); -->
<!-- //         	if(comfire==true) -->
<!-- //         		var a=document.getElementById("delete").value; -->
<!-- //         	　　  a.setAttribute("href","{$delete_url}"+nameValue); -->
<!-- //         	else -->
<!-- //         	　　return false; -->
<!-- // 		} -->
<!--         </script> -->
        
           <?php 
		$query = "select * from sensors where sensor_belong={$_SESSION['userId']}";
		$result = execute($conn, $query);
		while ($data = mysqli_fetch_assoc($result)){
			$main_url="main.php?sensor_id={$data['sensor_id']}";
			$delete_url="inc/sensor_delete.inc.php?sensor_id={$data['sensor_id']}&sensor_belong={$data['sensor_belong']}";
$html = <<<start
	<tr>
		<td>{$data['sensor_id']}</td>
		<td>{$data['sensor_func']}</td>
		<td>{$data['remarks']}</td>
		<td><a href="{$main_url}">[View]</a>&nbsp;&nbsp;<a href="{$delete_url}" id="delete">[Delete]</a></td>
	</tr>
start;
		echo $html;
		}
		?>
        </tr>
        </tbody>
    </table>
</form>
</center>
</body>
</html>
