<?php
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>login interface</title>
 
    <link rel="stylesheet" type="text/css" href="style/login.css"/>
    
</head>

<body>
<div id="login_frame">
 
    <p id="image_logo"><img src="images/logo.jpg"></p>
 
    <?php
	if (isset($_SESSION['userId'])) {
		echo 'You are already logged in '."<a href = 'sensor.php'>wirelessnation</a></br></br>";
		echo '<form action="inc/logout.inc.php" method="post">
			<button type="submit" name="logout-submit">logout</button>
		</form>';
	}
	else{
		if (isset($_GET['error'])) {
			if ($_GET['error'] == "emptyfields") {
				echo "<p class='signuperror'>Fill in all fields!</p>";
			}
			elseif ($_GET['error'] == "wrongpassword") {
				echo "<p class='signuperror'>Please check your username or password!</p>";
			}
			elseif ($_GET['error'] == "nouser") {
				echo "<p class='signuperror'>Please check your username or password!</p>";
			}
		}
$html  = <<<html
<form method="post" action="inc/login.inc.php">
<p>
    <label class="label_input">Username</label>
    <input type="text" id="username" class="text_field" name="mailuid" placeholder=" username or email"/>
</p>
<p>
    <label class="label_input">Password</label>
    <input type="password" id="password" class="text_field" name="pwd"/>
</p>
 
<div id="login_control">
	<button type="submit" id="btn_login" name="login-submit">LOGIN</button>
    <a id="signup" href="signup.php">SIGNUP</a>
</div>
</form>
html;

echo $html;
	}
	?>
    
</div>
 
</body>
</html>