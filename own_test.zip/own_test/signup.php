<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Signup interface</title>
    <link rel="stylesheet" type="text/css" href="style/login.css"/>  
</head>
 
<body>
<div id="signup_frame">

	<?php
	//$_GET: get key words from URL
		if (isset($_GET['error'])) {
			if ($_GET['error'] == "emptyfields") {
				echo "<p class='signuperror'>Fill in all fields!</p>";
			}
			elseif ($_GET['error'] == "invalidmailuid") {
				echo "<p class='signuperror'>Invalid E-mail and username!</p>";
			}
			elseif ($_GET['error'] == "invalidmail") {
				echo "<p class='signuperror'>Invalid E-mail!</p>";
			}
			elseif ($_GET['error'] == "invaliduid") {
				echo "<p class='signuperror'>Invalid username!</p>";
			}
			elseif ($_GET['error'] == "passwordcheck") {
				echo "<p class='signuperror'>Your password do not match!</p>";
			}
			elseif ($_GET['error'] == "usertaken") {
				echo "<p class='signuperror'>Username/E-mail is already taken!</p>";
			}
		}
		elseif (isset($_GET['signup'])&& $_GET['signup'] == "success") {
			echo "<p class='signuperror'>Signup successful!</p>";
		}
	?>
	 
    <form method="post" action="inc/signup.inc.php">
        <p>
        <label class="label_input">Username</label>
        <input type="text" id="username" name="uid" class="text_field"/>
        </p>
        
        <p>
        <label class="label_input">Email</label>
        <input type="text" id="mail" name="mail" class="text_field"/>
        </p>
        
        <p>
        <label class="label_input">Password</label>
        <input type="password" id="password" name="pwd" class="text_field"/>
        </p>
        
        <p>
        <label class="label_input">Confirm Password</label>
        <input type="password" id="newword" name="pwd-repeat" class="text_field"/>
        </p>
 
        <div id="signup_control">
            <button type="submit" id="btn_signup" name="signup-submit" value="SIGNUP" >SIGNUP</button>
            <a id="signup" href="login.php">LOGIN</a>
        </div>
    </form>
</div>

</body>
</html>