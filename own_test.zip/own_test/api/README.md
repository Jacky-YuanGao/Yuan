# API

## Dependencies

* Flask

You can install Flask with:

    pip3 install flask

## Usage

    python3 app.py