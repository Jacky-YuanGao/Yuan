#!/usr/bin/python3

from flask import Flask, jsonify
from parse import *

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>home</h1>'

@app.route('/all')
def all():
    data = [message for message in get_all()]
    return jsonify(data)

@app.route('/temp_and_humidity')
def temp_and_humidity():
    data = [message for message in get_all() if message['mode'] == 'temp_and_humidity']
    return jsonify(data)

@app.route('/light')
def light():
    data = [message for message in get_all() if message['mode'] == 'light']
    return jsonify(data)

@app.route('/door')
def door():
    data = [message for message in get_all() if message['mode'] == 'door']
    return jsonify(data)

@app.route('/button')
def button():
    data = [message for message in get_all() if message['mode'] == 'button']
    return jsonify(data)

@app.route('/vibration')
def vibration():
    data = [message for message in get_all() if message['mode'] == 'vibration']
    return jsonify(data)

@app.route('/magnet')
def magnet():
    data = [message for message in get_all() if message['mode'] == 'magnet']
    return jsonify(data)

if __name__ == "__main__":
    app.run()
