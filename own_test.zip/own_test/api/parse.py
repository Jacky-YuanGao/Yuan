#!/usr/bin/python3
import requests
import json
import time

ID = '2108E0'
login = " 5d2989a30499f54cd6028e0d"
password = "0f439f910e8dfb6ac85e3dbe4dfac842"
AUTH = (login, password)

def parse(r_json):
    for item in r_json['data']:
        time_str = time.ctime(item['time'] / 1000)
        seq_number = item['seqNumber']
        data = bin(int(item['data'], base=16))
        mode = int(data[0:3], base=2)
        mode_callbacks = {
            0: parse_button,
            1: parse_temp_humidity,
            2: parse_light,
            3: parse_door,
            4: parse_vibration,
            5: parse_magnet
        }
        yield mode_callbacks[mode](data, time_str, seq_number)


def parse_temp_humidity(data, time_str, seq_number): 
    
    temp_msb = int(data[12:16], base=2)
    temp_lsb = int(data[16:22], base=2)
    temp_f = temp_msb << 6 | temp_lsb
    temp_c = (temp_f - 200) / 8

    humidity = data[24:32]
    humidity = int(humidity, base=2) / 2
    
    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'temp_and_humidity',
        'temperature': temp_c,
        'humidity': humidity,
    }
    return d
    

def parse_light(data, time_str, seq_number):
    light_mask = int(data[22:24], base=2)
    light_value = int(data[16:22], base=2)

    if light_mask == 0:
        light_value = light_value / 96
    elif light_mask == 1:
        light_value = light_value * 8 / 96
    elif light_mask == 2:
        light_value = light_value * 64 / 96
    elif light_mask == 3:
        light_value = light_value * 1024 / 96

    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'light',
        'light': light_value
    }
    return d

def parse_door(data, time_str, seq_number):
    max_magnet = int(data[16:24], base=2)
    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'door',
        'max_magnet': max_magnet
    }

    return d

def parse_vibration(data, time_str, seq_number):
    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'vibration',
    }
    return d

def parse_magnet(data, time_str, seq_number):
    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'magnet',
    }
    return d

def parse_button(data, time_str, seq_number):
    d = {
        'seq_number': seq_number,
        'time': time_str,
        'mode': 'button',
    }


def get_all(id_=ID, authentication=AUTH):
    response = requests.get("https://api.sigfox.com/v2/devices/{id}/messages".format(id=id_),
                        auth=authentication,
                        )
    r_json = json.loads(response.text)
                
    for message in parse(r_json):
        yield message

if __name__ == "__main__":
    get_all()