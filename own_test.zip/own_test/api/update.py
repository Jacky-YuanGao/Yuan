#!/usr/bin/python3

import requests
import json
import os

def main():
    response = requests.get('http://localhost:5000/all')
    r_json = json.loads(response.text)
    if os.path.exists('data.json'):
        with open('data.json', 'r') as f:
            old_json = json.load(f)
            last_seq = -1
            for item in old_json:
                if item['seq_number'] > last_seq:
                    last_seq = item['seq_number']
    else:
        old_json = []
        last_seq = -1
    
    for item in r_json:
        if item['seq_number'] > last_seq:
            old_json.append(item)

    with open('data.json', 'w') as f:
        json.dump(old_json, f)

if __name__ == "__main__":
    main()
