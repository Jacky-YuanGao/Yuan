<?php
$headerArray =array("Content-type:application/json;","Accept:application/json");
$ch = curl_init();
$url = '127.0.0.1:5000/all';
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($url,CURLOPT_HTTPHEADER,$headerArray);
$output = curl_exec($ch);
curl_close($ch);
$response = json_decode($output,true);
