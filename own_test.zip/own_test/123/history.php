<?php
session_start();
header('Content_type:text/html;charset=utf-8');
if (isset($_SESSION['userUId'])) {
	include_once 'inc/config.inc.php';
	include_once 'inc/mysqli.inc.php';
	$conn = connect();
	include_once 'inc/history.inc.php';
	echo "hello {$_SESSION['userUId']}, here's the history of sensor {$_GET['sensor_id']}!";
}else {
	echo "Illegal access <a href = 'login.php'>please login</a>";
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>history</title>

<style type="text/css">
body {
	margin-left: 0px;
	margin-top: 0px;}
#aa {
	position: absolute;
	height: 800px;
	width: 100%;
	background: #FFF;}

#bb {
	background: #FFF;
	position: absolute;
	height: 90%;
	width: 95%;
	left: 51px;
	top: 0px;}
#cc {
	background: #09C;
	position: absolute;
	height: 63px;
	width: 100%;
	left: 0px;
	text-indent:15em;
	font-size: 42px;
	text-align: center;
	color: #FFF;}

#dd {
	position: absolute;
	height: 124px;
	width: 175px;
	left: 1142px;
	top: 136px;}
#ee {
	position: absolute;
	height: 295px;
	width: 510px;
	left: 50%;
	top: 70px;
	line-height: 24px;}
#ff {
	position: absolute;
	height: 66px;
	width: 214px;
	left: 650px;
	top: 583px;
	font-size: 18px;

	font-weight: bold;}
.gg {
		font-size: 36px;}
		#aa #bb #ee table tr td {
		color: #000;}
		#aa #bb #ee table {
		color: #000;}
		#gg {	position: absolute;
		height: 161px;
		width: 195px;
		left: 573px;
		top: 55px;
		font-size: 28px;}
		</style>
</head>

<body>
<div id="aa">

<div id="bb">
<div id="ee">
<table width="100%" border="1" align="center" cellpadding="0" cellspacing="0">
	<tr>
	<?php 
	$day_url = "day.php?sensor_id={$_GET['sensor_id']}";
	$week_url = "week.php?sensor_id={$_GET['sensor_id']}";
	?>
	<a name="day" href="<?php echo $day_url?>">Today</a>
	&nbsp;&nbsp;&nbsp;
	<a name="week" href="<?php echo $week_url?>">This Week</a>
	</tr>
	<tr>    
		<th>Time</th>  
    	<th>Temp</th>      
        <th>Door</th>      
        <th>Light</th>   
        <th>Magnet</th>  
        <th>Vibration</th>   
    </tr> 
     <?php 
     $query = "select * from history where sensor_id='{$_GET['sensor_id']}' order by id DESC";
     $result = execute($conn, $query);
     while ($data = mysqli_fetch_assoc($result)){
     	$html = <<<start
	<tr>
		<td>{$data['time']}</td>
		<td>{$data['TempandHum']}</td>
		<td>{$data['Door']}</td>
		<td>{$data['Light']}</td>
		<td>{$data['Magnet']}</td>
		<td>{$data['Vibration']}</td>
	</tr>
start;
     	echo $html;
     }
	?>
</table>
</div>
<img src="images\picture.jpg" width="100%" height="403" />
<div id="cc">History</div>
<div id="ff">
<div id="gg">
<?php 
$main_inc_url = "main.php?sensor_id={$_GET['sensor_id']}";
?>
<p> </p>
<p> </p>
<p> </p>
<p><a href="<?php echo $main_inc_url ?>">Back</a></p>
    </div>Wireless Nation 2019</div>
    </div>
</body>
</html>
