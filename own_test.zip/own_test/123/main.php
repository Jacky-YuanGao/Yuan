<?php
session_start();
header('Content_type:text/html;charset=utf-8');
if (isset($_SESSION['userUId'])) {
	include_once 'inc/config.inc.php';
	include_once 'inc/mysqli.inc.php';
    include_once 'req.php';
	$conn = connect();
	echo "hello {$_SESSION['userUId']}, welcome back, here is the sensor {$_GET['sensor_id']} : [{$_GET['remarks']}]!&nbsp;&nbsp;&nbsp;";
	echo "<a href='sensor.php'>Back</a>&nbsp;&nbsp;&nbsp;";
	echo "<a href='inc/logout.inc.php'>sign out</a>&nbsp;&nbsp;&nbsp;";
}else {
	echo "Illegal access <a href = 'login.php'>please login</a>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head> 
	<title>Wirelessnation</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href="style/style.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body id="animation">
	<span id="aa">time</span>
    <script>
    	setInterval("aa.innerHTML=new Date().toLocaleString()+' '.charAt(new Date().getDay());",1000);
	</script>  

<div class="wrap">
    <div class="header">
        <div class="logo">
            <a href="https://wirelessnation.co.nz/"><img src="images\wireless_nation.png" alt="" /> </a>
        </div>
    </div>

</div>
<div class="main-bg">
    <div class="wrap">
        <div class="main clearfix">
            <nav id="menu" class="nav">
                <ul>
                    <li>
                        <a href="#">
								<span class="icon">
									<i aria-hidden="true" class="icon-temperature"></i>
								</span>
                            <span>Temperature and Humidity</span>
                            <a href="#">
                            	<img src="images\T.jpg" width="200" height="200" alt="" />
                            </a>
                        </a>
                    </li>
                    <li>
                        <a href="#">
								<span class="icon">
									<i aria-hidden="true" class="icon-door"></i>
								</span>
                            <span>Door</span>
                            <a href="#"><img src="images\D.jpg" width="200" height="200"alt="" /> </a>
                        </a>
                    </li>
                    <li>
                        <a href="#">
								<span class="icon">
									<i aria-hidden="true" class="icon-light"></i>
								</span>
                            <span>Light</span>
                            <a href="#"><img src="images\L.jpg" width="200" height="200"alt="" /> </a>
                        </a>
                    </li>
                    <li>
                        <a href="#">
								<span class="icon">
									<i aria-hidden="true" class="icon-motion"></i>
								</span>
                            <span>Magnet</span>
                            <a href="#"><img src="images\M.gif" width="200" height="200"alt="" /> </a>
                      <li>
                        <a href="#">
                                <span class="icon">
                                    <i aria-hidden="true" class="icon-Vibration "></i>
                                </span>
                            <span>Vibration</span>
                            <a href="#"><img src="images\V.jpg" width="200" height="200"alt="" /> </a>
                        </a>
                    </li>

                </ul>

            </nav>
        </div>
    </div>
</div>
</body>

<head>  
    <title> New Document </title>  <meta name="Generator" content="EditPlus">  
    <meta charset="utf-8">  
    <style type="text/css">    *{       margin:0px;       padding:0px;    }    body table{        border:1px solid black;    }   
     th{        border:1px solid black;        text-align:center;        line-height:center;        width:400px;        height:30px;    }   
     td{        border:1px solid black;        text-align:center;        line-height:center;    }  
    </style> 
    <link href="style/style.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript">  
        function data(){
            var jsonObject=eval('('+str+')');        
        }  
	</script>  
</head>  

<?php 
$main_inc_url = "inc/main.inc.php?sensor_id={$_GET['sensor_id']}&remarks={$_GET['remarks']}";
$history_url = "history.php?sensor_id={$_GET['sensor_id']}&remarks={$_GET['remarks']}"
?>

<body>  
<form method="post" action="<?php echo $main_inc_url ?>">
	<table style="border: 1px;">   
	    <thead>    
	        <tr>      
	            <th>Temperature&Humdity</th>      
	            <th>Door</th>      
	            <th>Light</th>   
	            <th>Motion</th>  
	            <th>Vibration</th> 
                <th>Time</th> 
	            <th>
	            <input id='refresh' type='button' value='Refresh'>&nbsp;&nbsp;&nbsp;
	            <a href="<?php echo $history_url ?>"><input style="width:50px;height:20px;" type='button' value='History' ></a>
	            </th>   
	        </tr> 
	        <hr>
	        <tr>
				<td><input type="text" class="info_text" name="T" value="<?php echo $response[0]['temperature'] . '℃' . '/' . $response[0]['humidity']; ?>"></td>
				<td><input type="text" class="info_text" name="D"></td>
				<td><input type="text" class="info_text" name="L"></td>
				<td><input type="text" class="info_text" name="M"></td>
				<td><input type="text" class="info_text" name="V"></td>
                <td><input type="text" class="info_text" name="T" value="<?php echo !empty($response[0]['time']) ? date('Y-m-d H:i:s', strtotime($response[0]['time'])) : ''; ?>"></td>
				<td><button type='submit' name="sensor-info-submit">Store</button></td>
			</tr>
	    </thead>   
	</table>  
</form>	
<br>
<hr>
<div class="footer1">
    <p class="w3-link"><span>Wireless Nation 2019</a></span></p>
</div>

</body>
<script type="text/javascript">
    refresh = document.getElementById("refresh")
    refresh.onclick = function(){
        console.log(11);
        location.reload();
    }
</script>
</html>