-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2019-07-20 00:52:33
-- 服务器版本： 10.1.38-MariaDB
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `sigfox`
--

-- --------------------------------------------------------

--
-- 表的结构 `history`
--

CREATE TABLE `history` (
  `id` int(10) UNSIGNED NOT NULL,
  `sensor_id` text NOT NULL,
  `time` datetime NOT NULL,
  `TempandHum` text NOT NULL,
  `Door` text NOT NULL,
  `Light` text NOT NULL,
  `Magnet` text NOT NULL,
  `Vibration` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `history`
--

INSERT INTO `history` (`id`, `sensor_id`, `time`, `TempandHum`, `Door`, `Light`, `Magnet`, `Vibration`) VALUES
(4, '1', '2019-07-08 01:01:44', '1', '1', '1', '1', '1'),
(5, 'test1', '2019-07-11 00:00:00', '2', '2', '2', '2', '2'),
(6, 'test2', '2019-07-11 00:00:00', '2', '2', '2', '2', '2'),
(8, '123', '2019-07-08 17:32:29', '1', '1', '', '', ''),
(9, '2108', '2019-07-18 23:54:44', '63℃/68.5%', '', '', '', ''),
(10, '2108E0', '2019-07-18 23:58:31', '63℃/68.5%', '', '', '', ''),
(11, '2108E0', '2019-07-19 00:02:01', '63.125℃/4.5%', '', '', '', ''),
(12, '2108E0', '2019-07-19 00:43:55', '31.25℃/112%', '', '', '', ''),
(13, '2108E0', '2019-07-19 00:47:58', '31.25℃/4.5%', '', '', '', ''),
(14, '2108E0', '2019-07-19 05:08:01', '31.25℃/4.5%', '', '', '', ''),
(15, '2108E0', '2019-07-19 00:47:40', '31.25℃/4.5%', '', '', '', ''),
(17, '2108E0', '2019-07-20 08:57:00', '33℃/21.5%', '', '', '', ''),
(18, '2108E0', '2019-07-20 10:06:46', '		33.25℃/68.5%		', '				', '				', '				', '				'),
(20, '2108E0', '2019-07-20 10:13:40', '		33.25℃/100.5%		', '				', '				', '				', '				'),
(21, '2108E0', '2019-07-20 10:18:12', '		33.375℃/100.5%		', '				', '				', '				', '				');

-- --------------------------------------------------------

--
-- 表的结构 `sensors`
--

CREATE TABLE `sensors` (
  `id` int(11) NOT NULL,
  `sensor_belong` int(11) NOT NULL,
  `sensor_id` text NOT NULL,
  `sensor_func` text NOT NULL,
  `remarks` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sensors`
--

INSERT INTO `sensors` (`id`, `sensor_belong`, `sensor_id`, `sensor_func`, `remarks`) VALUES
(7, 1, '2108E0', 'Temp and Hum', '');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `idUser` int(11) NOT NULL,
  `uidUser` tinytext NOT NULL,
  `emailUser` tinytext NOT NULL,
  `pwdUser` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`idUser`, `uidUser`, `emailUser`, `pwdUser`) VALUES
(1, 'admin', '0211734456gy@gamil.com', '$2y$10$bQYTcxHmCByWZUy19M31qeKRAzug6S6WJcEKigajNeRE1xuZP9uC6'),
(2, 'yuan', '897618051@qq.com', '$2y$10$AkJ/6pHLPS75gvjcUjcpDuz1K7UYXxmLzL8VpCjAFy/.hxPcvkmgG');

--
-- 转储表的索引
--

--
-- 表的索引 `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `sensors`
--
ALTER TABLE `sensors`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUser`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `history`
--
ALTER TABLE `history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `sensors`
--
ALTER TABLE `sensors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
