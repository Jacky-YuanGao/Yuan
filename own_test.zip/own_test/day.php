<?php
session_start();
header('Content_type:text/html;charset=utf-8');
if (isset($_SESSION['userUId'])) {
	include_once 'inc/config.inc.php';
	include_once 'inc/mysqli.inc.php';
	$conn = connect();
	include_once 'inc/history.inc.php';

	$history_url = "history.php?sensor_id={$_GET['sensor_id']}";
	echo "hello {$_SESSION['userUId']}, here's the history of sensor {$_GET['sensor_id']}!";
}else {
	echo "Illegal access <a href = 'login.php'>please login</a>";
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>history</title>

<style type="text/css">
body {
	margin-left: 0px;
	margin-top: 0px;}
	
#aa {
	position: absolute;
	height: 100%;
	width: 100%;
	background: #FFF;}

#bb {
	background: url(images/picture.jpg) no-repeat;
	background-size: 100% 80%;
	background-attachment: fixed;
	position: absolute;
	height: 80%;
	width: 95%;
	left: 3%;
	top: 0px;}
	
#link {
	position: relative;
	left: 40%;
	top: 10px;
	line-height: 24px;
	overflow: auto;
	margin: 20px 10px;
	font-size: 24px}
	
#cc {
	background: #09C;
	position: absolute;
	height: 63px;
	width: 90%;
	left: 5%;
	bottom: 33px;
	text-indent:2em;
	font-size: 42px;
	text-align: center;
	color: #FFF;}

#dd {
	position: absolute;
	height: 124px;
	width: 175px;
	left: 1142px;
	top: 136px;}
	
#ee {
	position: relative;
	height: 70%;
	width: 50%;
	left: 40%;
	top: 10px;
	line-height: 24px;
	overflow: auto;
	margin: 20px 10px;}
	
#ff {
	position: absolute;
	height: 66px;
	width: 214px;
	left: 48%;
	top: 79%;
	font-size: 18px;
	font-weight: bold;}
	
#aa #bb #ee table tr td {
	color: #000;}
	
#aa #bb #ee table {
	color: #000;}

#gg {	
	position: absolute;
	height: 35px;
	width: 40px;
	left: 90%;
	top: 80%;
	font-size: 28px;}
		
.table-cont{
	max-height: 300px;
	overflow: auto;
	background: #ddd;
	margin: 20px 10px;
	box-shadow: 0 0 1px 3px #ddd;}

thead{
	background-color: #ddd;}

</style>

<!--this is scroll -->	
<script type="text/javascript">
			
// �̶���ͷ
 window.onload = function(){
  var tableCont = document.querySelector('#ee')
  function scrollHandle (e){
    console.log(this)
    var scrollTop = this.scrollTop;
    this.querySelector('thead').style.transform = 'translateY(' + scrollTop +'px)';
  }  
  tableCont.addEventListener('scroll',scrollHandle)
}

</script>
</head>

<body>

<div id="aa">
	<div id="bb">
		<div id="ee">
		
			<!--<div class='table-cont' id='table-cont'>-->			
						<?php day($conn); ?>

			<!--</div>-->
		</div>
		
		<div id="cc">Today</div>
			
    </div>
	<div id="ff">Wireless Nation 2019</div>
	<div id="gg">
	<?php 
	$main_inc_url = "main.php?sensor_id={$_GET['sensor_id']}";
	?>
	<p> </p>
	<p> </p>
	<p> </p>
	<p><a href="<?php echo $history_url ?>">Back</a></p>
	</div>
</div>

</body>
</html>
