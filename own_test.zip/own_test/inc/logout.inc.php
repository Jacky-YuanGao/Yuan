<?php

  session_start();

  setcookie($_SESSION['username'],'',time()-1);
  setcookie($_SESSION['sensor_id'],'',time()-1);
  session_unset();
  session_destroy();
  header("Location: ../login.php");

?>
