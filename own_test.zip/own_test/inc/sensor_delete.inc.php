<?php
include_once '../inc/config.inc.php';
include_once '../inc/mysqli.inc.php';
$conn=connect();
if (!isset($_GET['sensor_id'])) {
	exit("Illegal access <a href = '../sensor.php'>please check your sensor id</a>");
}

$query = "delete from sensors where sensor_id='{$_GET['sensor_id']}' and sensor_belong='{$_GET['sensor_belong']}';";
execute($conn, $query);
if (mysqli_affected_rows($conn)==1) {
	header("Location:../sensor.php?delete=success");
}else {
	echo mysqli_error($conn);
	exit();
	header("Location:../sensor.php?delete=failed");
}
?>
