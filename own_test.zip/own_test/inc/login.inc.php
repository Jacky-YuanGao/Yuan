<?php

  if(isset($_POST['login-submit'])) {

    include_once 'config.inc.php';
    include_once 'mysqli.inc.php';
    $conn = connect();
    
    $mailuid = $_POST['mailuid'];
    $password = $_POST['pwd'];

    if (empty($mailuid) || empty($password)) {
      header("Location: ../login.php?error=emptyfields");
      exit();
    }
    else {
      $sql = "SELECT * FROM users WHERE uidUser=? OR emailUser=?;";
      $stmt = mysqli_stmt_init($conn);

      if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../login.php?error=sqlerror-select");
        exit();
      }
      else{
        mysqli_stmt_bind_param($stmt, "ss", $mailuid, $mailuid);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        //mysqli_fetch_assoc: get a associated array from mysql raw data
        if ($row = mysqli_fetch_assoc($result)) {
          //password_verify: verifies that a password matches a hash
          $pwdCheck = password_verify($password, $row['pwdUser']);
          if ($pwdCheck == false) {
            header("Location: ../login.php?error=wrongpassword");
            exit();
          }
          else if($pwdCheck == true){
          	//$lifetime = 60;
          	//session_set_cookie_params($lifetime);
            session_start();
            $_SESSION['userId'] = $row['idUser'];
            $_SESSION['userUId'] = $row['uidUser'];

            header("Location: ../sensor.php");
            exit();
          }
          else{
            header("Location: ../login.php?error=wrongpassword");
            exit();
          }
        }
        else{
          header("Location: ../login.php?error=nouser");
          exit();
        }
      }
    }
  }
  else{
    header("Location: ../login.php?");
    exit();
  }

?>
