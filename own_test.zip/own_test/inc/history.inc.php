<?php
date_default_timezone_set('NZ');
function day($conn){
     $start = date('Y-m-d 00:00:00');
     $end = date('Y-m-d H:i:s');
     $query_day = "SELECT * FROM history WHERE unix_timestamp(time) >= unix_timestamp( '$start' ) AND unix_timestamp(time) <= unix_timestamp( '$end' ) and sensor_id='{$_GET['sensor_id']}';";
     $result_day = execute($conn, $query_day);
$th = <<<start
	<table class="table table-striped"  border="1" align="center" style="font-size:18px" cellpadding="0" cellspacing="0">
					<tr>
					
					</tr>
					
					<thead>
						<tr>    
							<th width="20%" height="45px">Time</th>  
							<th width="15%" height="45px">Temp</th>      
							<th width="15%" height="45px">Door</th>      
							<th width="15%" height="45px">Light</th>   
							<th width="15%" height="45px">Magnet</th>  
							<th width="15%" height="45px">Vibration</th>   
						</tr> 
					</thead>
start;
echo $th;
     while ($data_day = mysqli_fetch_assoc($result_day)){
     	$html_day = <<<start
	<tr>
		<td>{$data_day['time']}</td>
		<td>{$data_day['TempandHum']}</td>
		<td>{$data_day['Door']}</td>
		<td>{$data_day['Light']}</td>
		<td>{$data_day['Magnet']}</td>
		<td>{$data_day['Vibration']}</td>
	</tr>
start;
     	echo $html_day;
     }
     echo "</table>";
}

function week($conn){
	$start = date("Y-m-d H:i:s",mktime(0, 0, 0,date("m"),date("d")-((date('w') == 0 ? 7 : date('w')) - 1),date("Y")));
     $end = date("Y-m-d H:i:s",mktime(23,59,59,date("m"),date("d")-((date('w') == 0 ? 7 : date('w')))+7,date("Y")));
     $query_week = "SELECT * FROM history WHERE unix_timestamp(time) >= unix_timestamp( '$start' ) AND unix_timestamp(time) <= unix_timestamp( '$end' ) and sensor_id='{$_GET['sensor_id']}';";
     $result_week = execute($conn, $query_week);
$th = <<<start
	<table class="table table-striped"  border="1" align="center" style="font-size:18px" cellpadding="0" cellspacing="0">
					<tr>
					
					</tr>
					
					<thead>
						<tr>    
							<th width="20%" height="45px">Time</th>  
							<th width="15%" height="45px">Temp</th>      
							<th width="15%" height="45px">Door</th>      
							<th width="15%" height="45px">Light</th>   
							<th width="15%" height="45px">Magnet</th>  
							<th width="15%" height="45px">Vibration</th>   
						</tr> 
					</thead>
start;
echo $th;
     while ($data_week = mysqli_fetch_assoc($result_week)){
     	$html_day = <<<start
	<tr>
		<td>{$data_week['time']}</td>
		<td>{$data_week['TempandHum']}</td>
		<td>{$data_week['Door']}</td>
		<td>{$data_week['Light']}</td>
		<td>{$data_week['Magnet']}</td>
		<td>{$data_week['Vibration']}</td>
	</tr>
start;
     	echo $html_day;
     	
     }
     echo "</table>";
}
?>