<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '123QWEasd');
define('DB_DATABASE', 'sigfox');
define('DB_PORT', 3306);