<?php
session_start();
header('Content_type:text/html;charset=utf-8');
	
if (isset($_POST['sensor-info-submit'])) {
	include_once 'config.inc.php';
	include_once 'mysqli.inc.php';
	$conn = connect();
	date_default_timezone_set('NZ');
	$unix = date('Y-m-d H:i:s T');
	$query = "INSERT INTO history (sensor_id,time,TempandHum,Door,Light,Magnet,Vibration) VALUES (?,?,?,?,?,?,?)";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $query)) {
		echo mysqli_error($conn);
		exit();
	}
	else{
		mysqli_stmt_bind_param($stmt, "sssssss", $_GET['sensor_id'],$_POST['Time'], $_POST['T'], $_POST['D'], $_POST['L'],$_POST['M'],$_POST['V']);
		mysqli_stmt_execute($stmt);
		header("Location: ../main.php?store=success&sensor_id={$_GET['sensor_id']}&remarks={$_GET['remarks']}");
		exit();
	};
}
?>