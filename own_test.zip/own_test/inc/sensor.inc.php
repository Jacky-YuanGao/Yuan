<?php
session_start();
header('Content_type:text/html;charset=utf-8');

if (isset($_POST['addSensor-submit'])) {
	include_once 'config.inc.php';
	include_once 'mysqli.inc.php';
	$conn = connect();
	$sensor_id = $_POST['sensor_id'];
	if (empty($_POST['sensor_id'])) {
		header("Location: ../sensor.php?error=emptyfields");
		exit();
	}else{
		//'?' is a placeholder, it will be replaced by any user input value, Why don't use $username, because preventing SQL injection
		$sql = "SELECT sensor_id FROM sensors WHERE sensor_id=?";
		//Create a prepared statement
		$stmt = mysqli_stmt_init($conn);
		
		if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../sensor.php?error=sqlerror-select");
			exit();
		}else{
			mysqli_stmt_bind_param($stmt, "s", $sensor_id);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_store_result($stmt);
			$resultCheck = mysqli_stmt_num_rows($stmt);
			if($resultCheck > 0){
				header("Location: ../sensor.php?error=usertaken");
				exit();
			}else{
				$query = "INSERT INTO sensors (sensor_belong,sensor_id,sensor_func,remarks) VALUES (?,?,?,?)";
				$stmt = mysqli_stmt_init($conn);
				if (!mysqli_stmt_prepare($stmt, $query)) {
					echo mysqli_error($conn);
					exit();
				}
				else{
					mysqli_stmt_bind_param($stmt, "isss", $_SESSION['userId'],$_POST['sensor_id'], $_POST['sensor_func'], $_POST['remarks']);
					mysqli_stmt_execute($stmt);
					
					header("Location: ../sensor.php?success=success");
					exit();
				}
			}
		}
	}
}
?>